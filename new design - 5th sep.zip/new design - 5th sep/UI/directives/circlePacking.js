
app.directive('complete', function($window) {
    return function(scope, elem, attrs) {
      // var colorBakgroung=['#fafafa','#0fd09b','#0fd1da','#d6eb5b','#fafafa'];
      var colorBakgroung=['#ffdf96','#21a786','#806bd6','#79f1f7','#ff80ab'];
          // var colorBakgroung=['#fafafa','#ffdf96','#21a786','#806bd6','#fafafa'];
        var root = JSON.parse(attrs.object);
        // var div = d3.select("body").append("div")
        //     .attr("class", "tooltip")
        //     .style("opacity", 0);
        var svg = d3.select(elem[0].childNodes[1]),
            margin = 50,
            diameter = 750,
            g = svg.append("g")
                .attr("transform", "translate(" + diameter /1.5+ "," + diameter / 2.1 + ")")
                .attr('id','circle_svg');

        //legend_svg
        var svg1 = d3.select(".searchCard").append("svg")
                    .attr("id","legend_svg_circle")
                    .attr("width", "200")
                    .attr("height", "120");

        var fields = [{'name':'Industries','color':'#ffdf96'},{'name':'Accounts','color':'#21a786'},{'name':'Process','color':'#806bd6'},{'name':'Solutions','color':'#79f1f7'},{'name':'Tools','color':'#ff80ab'}];
        var legend = svg1.selectAll(".legend")
          .data(fields)
          .enter().append("g")
            .attr("class", "legend")
            .attr("transform", function(d, i) { return "translate(-225," + i * 20 + ")"; });

        // draw legend colored rectangles
        legend.append("rect")
            .attr("x", 282)
            .attr("y", 10)
            .attr("width", 18)
            .attr("height", 18)
            .attr("class","rect")
            .style("fill", function(d){ return d.color;});

        // draw legend text
        legend.append("text")
            .attr("x", 310)
            .attr("y", 18)

            .attr("dy", ".35em")
            .style("text-anchor", "start")
            .text(function(d) {return d.name;})

        var color = d3.scaleLinear()
            .domain([-1, 5])
            .range(["hsl(152,80%,80%)", "hsl(228,30%,40%)"])
            .interpolate(d3.interpolateHcl);

        var pack = d3.pack()
            .size([diameter - margin, diameter - margin])
            .padding(2);

        root = d3.hierarchy(root)
            .sum(function(d) {
                return d.size;
            })
            .sort(function(a, b) {
                return b.value - a.value;
            });

        var focus = root,
            nodes = pack(root).descendants(),
            view;

        var scope=angular.element(document.querySelector('[ng-controller="Controller"]')).scope()
        scope.zoom = function(node) {
          // console.log(node);
            if (node.name != "Industry") {
                zoom(node.zoom);
            } else {
                scope.industries();
            }
        };

        var circle = g.selectAll("circle")
            .data(nodes)
            .enter().append("circle")
            .attr("class", function(d) {
              if(d.data.name!=""){
                return d.parent ? d.children ? "node" : "node" : "node node--root";
              }else{
                return d.parent ? d.children ? "node" : "node node--leaf" : "node node--root";
              }
            })
            .style("fill", function(d) {
              if(d.data.name!=""){
                return  colorBakgroung[d.depth] ;
              }else{
                return  colorBakgroung[d.depth-1];
              }
            })
            .on("click", function(d) {
                if (attrs.breadcrum == "Accounts") {
                  if(d.depth!=4){
                    scope.accountBreadCrum(d);
                  }else if(scope.breadCrumArray.length==5){
                    scope.displayLeafDetails(d);
                  }else{
                    scope.accountBreadCrum(d);
                  }
                } else if (attrs.breadcrum == "Process") {
                    scope.breadCrum(d);
                }
                d3.event.stopPropagation();
            })
            // .on("mouseover", function(d) {
            //     div.transition()
            //         .duration(200)
            //         .style("opacity", .9);
            //     div.html("<h5>" + d.data.name + "</h5>")
            //     .style("left", (d3.event.pageX) + "px")
            //     .style("top", (d3.event.pageY - 28) + "px");
            //     })
            // .on("mouseout", function(d) {
            //    div.transition()
            //         .duration(500)
            //         .style("opacity", 0)
            //   });

        var text = g.selectAll("node")
            .data(nodes)
            .enter().append("text")
            .attr("class", "label")
            .attr("id","eclipse")
            .style("fill-opacity", function(d) {
                return d.parent === root ? 1 : 0;
            })
            .style("display", function(d) {
                return d.parent === root ? "inline" : "none";
            })

            .text(function(d) {
              // if(d.data.name.length> 10){
              //   return d.data.name.substr(0,10)+"...";
              // }
              // else {
                return d.data.name;
              // }
            });

        var node = g.selectAll("circle,text");

        svg
            .style("background", "white")
            .on("click", function() {
                zoom(root);
            });

        zoomTo([root.x, root.y, root.r * 2 + margin]);

        function zoom(d) {
            // console.log(d);
            // console.log("in zoom");
            var focus0 = focus;
            focus = d;

            var transition = d3.transition()
                .duration(400)
                .tween("zoom", function(d) {


                    var i = d3.interpolateZoom(view, [focus.x, focus.y, focus.r * 2 + margin]);
                    return function(t) {
                        zoomTo(i(t));
                    };
                });

            transition.selectAll("text")
                .filter(function(d) {
                    return d.parent === focus || this.style.display === "inline";
                })
                .style("fill-opacity", function(d) {
                    return d.parent === focus ? 1 : 0;
                })
                .on("start", function(d) {
                    if (d.parent === focus) this.style.display = "inline";
                })
                .on("end", function(d) {
                    if (d.parent !== focus) this.style.display = "none";
                });
        }

        function zoomTo(v) {
            var k = diameter / v[2];
            view = v;
            node.attr("transform", function(d) {
                return "translate(" + (d.x - v[0]) * k + "," + (d.y - v[1]) * k + ")";
            });
            circle.attr("r", function(d) {
                return d.r * k;
            });
        }

    }
});
