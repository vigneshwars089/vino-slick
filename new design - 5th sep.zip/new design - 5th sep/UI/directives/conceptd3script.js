var nodeI = [];
var c = 0;

function drawConceptMap(result, top_tool)
{
  var scope=angular.element(document.querySelector('[ng-controller="Controller"]')).scope()
  var newObj;
  var newStr="";
  newStr = JSON.stringify(result);
  newObj=JSON.parse(newStr);


  d3.select("#legend_svg").remove();


var top_tool = top_tool;
var data = [];
var fields = [{'name':"Industries",'color':'#E9D460'},{'name':"Processes",'color':'#f27f7e'},
              {'name':"Solutions",'color':'#bb9fe6'},{'name':"Tools",'color':'#58cf99'},
              {'name':"Accounts",'color':'#6BB9F0'}
            ];

var arr1 = [];
var arr2 = [];
var arr3 = [];
var arr = [];
var alpha = [];

arr = newObj.data;

arr.sort();
  for(i=0;i<arr.length;i++)
    alpha.push(arr[i][0].charAt(0));
  var c_index = alpha.lastIndexOf('C')+1;
  var k_index = alpha.lastIndexOf('H')+1;
  var s_index = alpha.lastIndexOf('Q')+1;


var k_indexx = k_index;
var s_indexx = s_index;

arr1 = arr.splice(0, c_index);
k_index = k_index-c_index;
arr2 = arr.splice(0, k_index);
s_index = s_index-(k_index+c_index);
arr3 = arr.splice(0, s_index);

var index = 0;
var divs = [{'arr':arr1,'div':'conceptMapDiv1'},
            {'arr':arr2,'div':'conceptMapDiv2'},
            {'arr':arr3,'div':'conceptMapDiv3'},
            {'arr':arr,'div':'conceptMapDiv4'}];

for(i=0;i<divs.length;i++){
  for(j=0;j<divs[i]['arr'].length;j++){
    if(divs[i]['arr'][j][index]==top_tool){
      var i_index = i;
      drawGraph(divs[i]['arr'],'#'+divs[i]['div'],top_tool);
      scope[divs[i]['div']] = true;
    }
  }
}
for(i=0;i<divs.length;i++){
  if(i!=i_index)
    drawGraph(divs[i]['arr'],'#'+divs[i]['div'],top_tool);
}

var svg2 = d3.select("#legend")
    .append("svg")
    .attr("id","legend_svg")
    .attr("width", 300)
    .attr("height", 200);
    // draw legend
    var legend = svg2.selectAll(".legend")
        .data(fields)
      .enter().append("g")
        .attr("class", "legend")
        .attr("transform", function(d, i) { return "translate(-170," + i * 20 + ")"; });

    // draw legend colored rectangles
    legend.append("rect")
        .attr("x", 282)
        .attr("y", 10)
        .attr("width", 18)
        .attr("height", 18)
        .style("fill", function(d){ return d.color;});

    // draw legend text
    legend.append("text")
        .attr("x", 310)
        .attr("y", 18)
        .attr("dy", ".35em")
        .style("text-anchor", "start")
        .text(function(d) { return d.name;});
//   drawGraph(arr1,"#conceptMapDiv1",top_tool);
//
//   setTimeout(function(){
//     drawGraph(arr2,"#conceptMapDiv2",top_tool);
//   },0);
//
//   setTimeout(function(){
//     drawGraph(arr3,"#conceptMapDiv3",top_tool);
//   },0);
//
//   setTimeout(function(){
//     drawGraph(arr,"#conceptMapDiv4",top_tool);
//   },0);
}

  function drawGraph(data,div,top_tool){
      var colors =  ['#E9D460','#f27f7e','#bb9fe6','#6BB9F0'];
      var scope=angular.element(document.querySelector('[ng-controller="Controller"]')).scope()
      data = data;
      c++;

// transform the data into a useful representation
// 1 is inner, 2, is outer
// need: inner, outer, links
//
// inner:
// links: { inner: outer: }
var outer = d3.map();
var inner = [];
var links = [];
var outerId = [0];
data.forEach(function(d){
        if (d == null)
              return;
              if(div=="#conceptMapDiv1")
                i = { id: 'i1' + inner.length, name: d[0], related_links: [] };
              else if(div=="#conceptMapDiv2")
                i = { id: 'i2' + inner.length, name: d[0], related_links: [] };
              else if(div=="#conceptMapDiv3")
                i = { id: 'i3' + inner.length, name: d[0], related_links: [] };
              else
                i = { id: 'i4' + inner.length, name: d[0], related_links: [] };
                i.related_nodes = [i.id];
                inner.push(i);
                if (!Array.isArray(d[1]))
                  d[1] = [d[1]];
                  d[1].forEach(function(d1){
                                o = outer.get(d1);
                                if (o == null)
                                {
                                  var a = 0;
                                  if(div=="#conceptMapDiv1")
                                    o = { name: d1,  id: 'o1' + outerId[0], related_links: [] };
                                  else if(div=="#conceptMapDiv2")
                                    o = { name: d1,  id: 'o2' + outerId[0], related_links: [] };
                                  else if(div=="#conceptMapDiv3")
                                    o = { name: d1,  id: 'o3' + outerId[0], related_links: [] };
                                  else
                                    o = { name: d1,  id: 'o4' + outerId[0], related_links: [] };
                                  o.related_nodes = [o.id];
                                  o.group = outerId[0];
                                  outerId[0] = outerId[0] + 1;
                                  outer.set(d1, o);
                                }

                                // create the links
                                l = { id: 'l-' + i.id + '-' + o.id, inner: i, outer: o }
                                links.push(l);

                                // and the relationships
                                i.related_nodes.push(o.id);
                                i.related_links.push(l.id);
                                o.related_nodes.push(i.id);
                                o.related_links.push(l.id);
                });
});
data = {
      inner: inner,
      outer: outer.values(),
      links: links
}
// sort the data -- TODO: have multiple sort options
outer = data.outer;
data.outer = Array(outer.length);
var i1 = 0;
var i2 = outer.length - 1;
for (var i = 0; i < data.outer.length; ++i)
{
                if (i % 2 == 1)
                                data.outer[i2--] = outer[i];
                else
                                data.outer[i1++] = outer[i];
}

nodeI.push(data.inner);

var diameter = 1150;
var rect_width = 270;
var rect_height = 17;
var link_width = "1px";
var il = data.inner.length;
var ol = data.outer.length;
var inner_y = d3.scale.linear()
    .domain([0, il])
    .range([-(il * rect_height)/2, (il * rect_height)/2]);
mid = (data.outer.length/2.0)
var outer_x = d3.scale.linear()
    .domain([0, mid, mid, data.outer.length])
    .range([55, 130, 230 ,315]);
var outer_y = d3.scale.linear()
    .domain([0, data.outer.length])
    .range([0, diameter / 2 - 120]);
// setup positioning
data.outer = data.outer.map(function(d, i) {
    d.x = outer_x(i);
    d.y = diameter/3;
    return d;
});
data.inner = data.inner.map(function(d, i) {
    d.x = -(rect_width / 2);
    d.y = inner_y(i);
    return d;
});
function get_color(name)
{
  var c = name;
  if (isNaN(c))
    return '#dddddd';    // fallback color
  return colors[c];
}
function get_color1(group)
{
      var c = group;
      return colors[c];
}
function get_color2(group)
{
      var c = group;
      return "#58cf99";
}

// Can't just use d3.svg.diagonal because one edge is in normal space, the
// other edge is in radial space. Since we can't just ask d3 to do projection
// of a single point, do it ourselves the same way d3 would do it.
function projectX(x)
{
    return ((x - 90) / 180 * Math.PI) - (Math.PI/2);
}
var diagonal = d3.svg.diagonal()
    .source(function(d) { return {"x": d.outer.y * Math.cos(projectX(d.outer.x)),
                                  "y": -d.outer.y * Math.sin(projectX(d.outer.x))}; })
    .target(function(d) { return {"x": d.inner.y + rect_height/2,
                                  "y": d.outer.x > 180 ? d.inner.x : d.inner.x + rect_width}; })
    .projection(function(d) { return [d.y, d.x]; });

var svg = d3.select(div).append("svg")
    .attr("id",div)
    .attr("width", diameter)
    .attr("height", "1000")
    .append("g")
    .attr("transform", "translate(" + diameter / 2 + "," + diameter / 2.3 + ")")

// links
var link = svg.append('g').attr('class', 'links').selectAll(".link")
    .data(data.links)
  .enter().append('path')
    .attr('class', 'linkConcept')
    .attr('id', function(d) { return d.id })
    .attr("d", diagonal)
    .attr('stroke', function(d) { return "get_color(d.inner.name)"; })
    .attr('stroke-width', link_width)
    .attr('opacity', '0.2');

    // outer nodes
    var onode = svg.append('g').selectAll(".outer_node")
        .data(data.outer)
      .enter().append("g")
        .attr("class", "outer_node")
        .attr("transform", function(d) { return "rotate(" + (d.x - 90) + ")translate(" + d.y + ")"; })
        .on("mouseover", mouseover1)
        .on("mouseout", mouseout1);

    onode.append("circle")
        .attr('id', function(d) { return d.id })
        .attr("r", 10.5)
        .attr("class","onode_circle")
        .attr('opacity', '0.2')

    onode.append("circle")
        .attr('r', 20)
        .attr("class","onode_circle_hidden")
        .attr('visibility', 'hidden')
        .append("svg:title")
          .text(function(d, i) { return d.name; });

    onode.append("text")
        .attr('id', function(d) { return d.id + '-txt'; })
        .attr("dy", ".35em")
        .attr("text-anchor", function(d) { return d.x < 180 ? "start" : "end"; })
        .attr("transform", function(d) { return d.x < 180 ? "translate(18)" : "rotate(180)translate(-18)"; })
        .text(function(d) {
          if(d.name.length>20){
            return d.name.substr(0,20)+"...";
          }else{
            return d.name;
          }
        })
        .style("font-size", "15px")
        .style("font-family", "Segoe UI")
        .attr('opacity', '0.2');

// inner nodes
var inode = svg.append('g').selectAll(".inner_node")
    .data(data.inner)
  .enter().append("g")
    .attr("class", "inner_node")
    .attr('id','iNode')
    .attr("transform", function(d, i) { return "translate(" + d.x + "," + d.y + ")"})
    .on("mouseover", mouseover)
    .on("mouseout", mouseout)
    .on("click", clicked);

inode.append('rect')
    .attr('fill', function(d) { return '#58cf99'; })
    .attr('width', rect_width)
    .attr('height', rect_height)
    // .attr("transform", "translate(2px,2px)")
    .attr('id', function(d) { return d.id; })
    .attr("border","1px")
    .append("svg:title")
      .text(function(d, i) { return d.name; })

inode.append("text")
                .attr('id', function(d) { return d.id + '-txt'; })
    .attr('text-anchor', 'middle')
    .attr("transform", "translate(" + rect_width/2 + ", " + rect_height * .75 + ")")
    .text(function(d) {
      if(d.name.length>40){
        return d.name.substr(0,40)+"...";
      }else{
        return d.name;
      }
    })
    .style("font-family", "Segoe UI")

// need to specify x/y/etc
d3.select(self.frameElement).style("height", diameter - 150 + "px");


// onode.selectAll('circle')
//     .data(data.inner).enter().append("circle")
//     .attr("fill", function(d){
      // console.log(d);

      for (var i = 0; i < data['inner'].length; i++)
        for (var j = 1; j < data['inner'][i].related_nodes.length; j++)
        {
            d3.select('#' + data['inner'][i].related_nodes[j]).attr("fill", colors[j-1]);
        }
    // })



// Initial highlight

for(i=0;i<data.inner.length;i++){
  if(top_tool==data.inner[i].name){
    for(j=0;j<data.inner[i].related_nodes.length;j++)
    {
      d3.select('#' + data.inner[i].related_nodes[j]).classed('highlight', true);
      d3.select('#' + data.inner[i].related_nodes[j] + '-txt').attr("font-size", '15px');
      d3.select('#' + data.inner[i].related_nodes[j] + '-txt').attr("font-weight", 'bold');
      d3.select('#' + data.inner[i].related_nodes[j] + '-txt').attr('opacity', '1').attr("fill","brown");
      d3.select('#' + data.inner[i].related_nodes[j]).attr('opacity', '1');
    }
    for (var k = 0; k < data.inner[i].related_links.length; k++)
        d3.select('#' + data.inner[i].related_links[k]).attr('stroke-width', '7px').attr("stroke", get_color1(k)).attr('opacity', '1');
  }
}





function mouseover(d)
{
    d3.selectAll('.links .link').sort(function(a, b){ return d.related_links.indexOf(a.id); });
    // Initial highlight
    // for(i=0;i<data.inner.length;i++){
    //   if(top_tool==data.inner[i].name){
    //   for(j=0;j<data.inner[i].related_nodes.length;j++)
    //     {
    //       d3.select('#' + data.inner[i].related_nodes[j]).classed('highlight', false);
    //       d3.select('#' + data.inner[i].related_nodes[j] + '-txt').attr("font-weight", 'normal');
    //       d3.select('#' + data.inner[i].related_nodes[j+1] + '-txt').attr('opacity','0.2');
    //       d3.select('#' + data.inner[i].related_nodes[j+1]).attr('opacity','0.2');
    //     }
    //     for (var k = 0; k < data.inner[i].related_links.length; k++)
    //         d3.select('#' + data.inner[i].related_links[k]).attr('stroke-width', link_width).attr("stroke", 'none').attr('opacity', '0.2');
    //   }
    // }
    for (var i = 0; i < d.related_nodes.length; i++)
    {
        d3.select('#' + d.related_nodes[i]).classed('highlight', true);
        d3.select('#' + d.related_nodes[i] + '-txt').attr("font-weight", 'bold').attr("fill", 'brown');
        d3.select('#' + d.related_nodes[i+1] + '-txt').attr('opacity', '1');
        d3.select('#' + d.related_nodes[i+1]).attr('opacity', '1');
    }
    for (var i = 0; i < d.related_links.length; i++)
        d3.select('#' + d.related_links[i]).attr('stroke-width', '7px').attr("stroke", get_color1(i)).attr('opacity', '1');
}
function mouseout(d)
{
    for (var i = 0; i < d.related_nodes.length; i++)
    {
        d3.select('#' + d.related_nodes[i]).classed('highlight', false);
        d3.select('#' + d.related_nodes[i] + '-txt').attr("font-weight", 'normal').attr("fill", 'black');
        d3.select('#' + d.related_nodes[i+1] + '-txt').attr('opacity', '0.2');
        d3.select('#' + d.related_nodes[i+1]).attr('opacity', '0.2');
    }
    for (var i = 0; i < d.related_links.length; i++)
        d3.select('#' + d.related_links[i]).attr('stroke-width', link_width).attr("stroke", 'none').attr('opacity', '0.2');
}
function mouseover1(d)
{
  // Initial highlight
  // for(i=0;i<data.inner.length;i++){
  //   if(top_tool==data.inner[i].name){
  //   for(j=0;j<data.inner[i].related_nodes.length;j++)
  //     {
  //       d3.select('#' + data.inner[i].related_nodes[j]).classed('highlight', false);
  //       d3.select('#' + data.inner[i].related_nodes[j] + '-txt').attr("font-weight", 'normal').attr("fill", 'black');
  //       d3.select('#' + data.inner[i].related_nodes[0] + '-txt').attr('opacity', '1');
  //       if(j!=0){
  //         d3.select('#' + data.inner[i].related_nodes[j] + '-txt').attr('opacity', '0.2');
  //       d3.select('#' + data.inner[i].related_nodes[j]).attr('opacity', '0.2');
  //     }
  //     }
  //     for (var k = 0; k < data.inner[i].related_links.length; k++)
  //         d3.select('#' + data.inner[i].related_links[k]).attr('stroke-width', link_width).attr("stroke", 'none').attr('opacity', '0.2');
  //   }
  // }
    // bring to front
   d3.selectAll('.links .link').sort(function(a, b){ return d.related_links.indexOf(a.id); });
    for (var i = 0; i < d.related_nodes.length; i++)
    {
        d3.select('#' + d.related_nodes[i]).classed('highlight', true);
        d3.select('#' + d.related_nodes[i] + '-txt').attr("font-weight", 'bold').attr('opacity', '1');
        d3.select('#' + d.related_nodes[i] ).attr('opacity', '1');
    }
    for (var i = 0; i < d.related_links.length; i++)
        d3.select('#' + d.related_links[i]).attr('stroke-width', '7px').attr("stroke", '#58cf99').attr('opacity', '1');
}
function mouseout1(d)
{
    for (var i = 0; i < d.related_nodes.length; i++)
    {
        d3.select('#' + d.related_nodes[i]).classed('highlight', false);
        d3.select('#' + d.related_nodes[i] + '-txt').attr("font-weight", 'normal').attr("fill", 'black');
        d3.select('#' + d.related_nodes[0] + '-txt').attr('opacity', '0.2');
        d3.select('#' + d.related_nodes[0] ).attr('opacity', '0.2');

    }
    for (var i = 0; i < d.related_links.length; i++)
        d3.select('#' + d.related_links[i]).attr('stroke-width', link_width).attr("stroke", 'none').attr('opacity', '0.2');
}

        scope.loadBar = false;

}

function update(term){
  num = 0;
  d3.select('#iNode').selectAll('rect.inner_node')
      .data(nodeI[0]).enter().append("g")
      .attr('id','filled')
      .attr("fill", function(d){
        if(d.name.charAt(0) == term){
            d3.select('#' + d.related_nodes[0]).attr("fill", "#FCF3CF");
            num = d['id'].substring(2);
            if(num>30){
              document.getElementById( 'bottom' ).scrollIntoView();
            }else
              document.getElementById( 'mainDiv' ).scrollIntoView();
          }
        else{
          d3.select('#' + d.related_nodes[0]).attr("fill", "#58cf99");
        }
    })
      d3.select('#iNode').selectAll('rect.inner_node')
          .data(nodeI[1]).enter().append("g")
          .attr('id','filled1')
          .attr("fill", function(d){
            if(d.name.charAt(0) == term)
              {
                d3.select('#' + d.related_nodes[0]).attr("fill", "#FCF3CF");
                num = d['id'].substring(2);
                if(num>30){

                  document.getElementById('bottom').scrollIntoView();

                }
                else
                  document.getElementById( 'mainDiv' ).scrollIntoView();
              }
            else
              d3.select('#' + d.related_nodes[0]).attr("fill", "#58cf99");
          })
          d3.select('#iNode').selectAll('rect.inner_node')
              .data(nodeI[2]).enter().append("g")
              .attr('id','filled2')
              .attr("fill", function(d){
                if(d.name.charAt(0) == term){
                  d3.select('#' + d.related_nodes[0]).attr("fill", "#FCF3CF");
                  num = d['id'].substring(2);
                  if(num>30)
                    document.getElementById('bottom').scrollIntoView();
                  else{
                      document.getElementById( 'mainDiv' ).scrollIntoView();
                  }
                }
                else{
                  d3.select('#' + d.related_nodes[0]).attr("fill", "#58cf99");
                }
              })
              d3.select('#iNode').selectAll('rect.inner_node')
                  .data(nodeI[3]).enter().append("g")
                  .attr('id','filled3')
                  .attr("fill", function(d){
                    if(d.name.charAt(0) == term){
                      d3.select('#' + d.related_nodes[0]).attr("fill", "#FCF3CF");
                      num = d['id'].substring(2);
                      if(num>30)
                        document.getElementById( 'bottom' ).scrollIntoView();
                        else
                          document.getElementById( 'mainDiv' ).scrollIntoView();
                    }
                    else
                      d3.select('#' + d.related_nodes[0]).attr("fill", "#58cf99");
                  })

}
function clicked(d){

    d3.select('#' + d.related_nodes[1]).append("svg:title")
      .text(function(d, i) { return d.name; })
}
