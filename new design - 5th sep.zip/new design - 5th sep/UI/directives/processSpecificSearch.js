app.directive('processsearch', function($window) {
    // var d3 = $window.d3;

    return function(scope, elem, attrs) {
      var count=0;

      var tip = d3.tip()
        .attr('class', 'd3-tip')
        .offset([-10, 0])
        .html(function(d) {
          return "<span style='color:white'>" + d.name + "</span>";
        })
        var screenHeight= (window.screen.availHeight*70)/100
      var fields = JSON.parse(attrs.fields);

        var margin = {
                top: 20,
                right: 20,
                bottom: 20,
                left: 150
            },
            width = 1200 - margin.right - margin.left,
            height = screenHeight - margin.top - margin.bottom;

        var i = 0,
            duration = 550,
            root;

        var tree = d3.layout.tree()
            .size([height, width]);

        var diagonal = d3.svg.diagonal()
            .projection(function(d) {
                return [d.y, d.x];
            });

        var svg = d3.select(elem[0]).append("svg")
            .attr("width", width + margin.right + margin.left)
            .attr("height", screenHeight + margin.top + margin.bottom)
            .append("g")
            .attr("transform", "translate(200," + margin.top + ")");
            svg.call(tip);


            root = JSON.parse(attrs.object);
            root.x0 = screenHeight / 2;
            root.y0 = 0;

            function collapse(d) {
                if (d.children) {
                    d._children = d.children;
                    d._children.forEach(collapse);
                    d.children = null;
                }
            }

            root.children.forEach(function(node){
              node.children.forEach(collapse);
            });
            update(root);


        d3.select(self.frameElement).style("height", screenHeight);

        function update(source) {

            // Compute the new tree layout.
            var nodes = tree.nodes(root).reverse(),
                links = tree.links(nodes);

            // Normalize for fixed-depth.
            nodes.forEach(function(d) {
                d.y = d.depth * 180;
            });

            // Update the nodes…
            var node = svg.selectAll("g.node")
                .data(nodes, function(d) {
                    return d.id || (d.id = ++i);
                });

            // Enter any new nodes at the parent's previous position.
            var nodeEnter = node.enter().append("g")
                .attr("class", "node")
                .attr("id","rectResize")
                .attr("transform", function(d) {
                    return "translate(" + source.y0 + "," + source.x0 + ")";
                })
                .on("click", click);

            nodeEnter.append("circle")
                .attr("r", 1e-6)
                .style("fill", function(d) {
                  // console.log(d);
                    return fields[d.depth].color;
                })
                .on('mouseover', tip.show)
                .on('mouseout', tip.hide);

            nodeEnter.append("text")
                .attr("x", function(d) {
                    return d.children || d._children ? -10 : 16;
                })
                .attr('id','searchText')
                .attr("dx", "-0.30em")
                .attr("dy", ".40em")
                .attr("text-anchor", function(d) {
                    return d.children || d._children ? "end" : "start";
                })
                // .attr("title", function(d) {
                //     return d.name;
                // })
                .text(function(d) {
                  if(d.name.length>18){
                    return d.name.substr(0,18)+"...";
                  }else{
                    return d.name;
                  }
                })
                .style("fill-opacity", 1e-6)
                .on('mouseover', tip.show)
                .on('mouseout', tip.hide);

            // Transition nodes to their new position.
            var nodeUpdate = node.transition()
                .duration(duration)
                .attr("transform", function(d) {
                    return "translate(" + d.y + "," + d.x + ")";
                });

            nodeUpdate.select("circle")
                .attr("r", 10)
                .style("fill",function(d) {
                  // console.log(d);
                    return d.children || d._children ? "end" : "start";
                });

            nodeUpdate.select("text")
                .style("fill-opacity", 1);

            // Transition exiting nodes to the parent's new position.
            var nodeExit = node.exit().transition()
                .duration(duration)
                .attr("transform", function(d) {
                    return "translate(" + source.y + "," + source.x + ")";
                })
                .remove();

            nodeExit.select("circle")
                .attr("r", 1e-6);

            nodeExit.select("text")
                .style("fill-opacity", 1e-6);

            // Update the links…
            var link = svg.selectAll("path.link")
                .data(links, function(d) {
                    return d.target.id;
                });

            // Enter any new links at the parent's previous position.
            link.enter().insert("path", "g")
                .attr("class", "link")
                .attr("d", function(d) {
                    var o = {
                        x: source.x0,
                        y: source.y0
                    };
                    return diagonal({
                        source: o,
                        target: o
                    });
                });

            // Transition links to their new position.
            link.transition()
                .duration(duration)
                .attr("d", diagonal);

            // Transition exiting nodes to the parent's new position.
            link.exit().transition()
                .duration(duration)
                .attr("d", function(d) {
                    var o = {
                        x: source.x,
                        y: source.y
                    };
                    return diagonal({
                        source: o,
                        target: o
                    });
                })
                .remove();

            // Stash the old positions for transition.
            nodes.forEach(function(d) {
                d.x0 = d.x;
                d.y0 = d.y;
            });
        }

        function click(d) {
          if(d.depth==2){
            scope.populateTreeTable(d);
          }
            if (d.children) {
                d._children = d.children;
                d.children = null;
            } else {
                d.children = d._children;
                d._children = null;
            }
            update(d);
        }
        var svg1 = d3.select(elem[0].childNodes[1]).append("svg")
                    .attr("id","legend_svg")
                    .attr("width", 1800)
                    .attr("height", 110);

        var legend = svg1.selectAll(".legend")
          .data(fields)
          .enter().append("g")
            .attr("class", "legend")
            .attr("transform", function(d, i) { return "translate(-250," + i * 20 + ")"; });

        // draw legend colored rectangles
        legend.append("rect")
            .attr("x", 282)
            .attr("y", 10)
            .attr("width", 18)
            .attr("height", 18)
            .attr("class","rect")
            .style("fill", function(d){ return d.color;});

        // draw legend text
        legend.append("text")
            .attr("x", 310)
            .attr("y", 18)

            .attr("dy", ".35em")
            .style("text-anchor", "start")
            .text(function(d) { if(d.name!="Verticals"){
              return d.name
            }else{
              return "Industries"
            }
          })

    }
});
