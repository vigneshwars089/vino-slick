
angular.module('App')
.controller('LoginCtrl',function($scope,$state,sharedURL, GetNameService,angularLoad,$http,$compile,$timeout,$mdDialog,userDetails){
    token = '';
    $scope.username="";
    $scope.password="";
    $scope.token = '';
    $scope.loadCircularBar=true;
    var servercheck = 0;

// Initial server up/down check
    $timeout(serverFunction, 1000);
    function serverFunction() {
        $http.get(sharedURL.getURL()).success(function(result){
                $timeout(serverFunction, 1000);
              })
              .error(function(err){
                $timeout(showConfirm, 1000);
              });
      }
   function showConfirm(ev) {
      servercheck++;
      var confirm = $mdDialog.confirm()
            .title('Server is down !!!')
            .textContent('Do you want to retry ??')
            .targetEvent(ev)
            .ok('Retry')
            .cancel('close');
      if(servercheck<=3){
        $mdDialog.show(confirm).then(function() {
          $timeout(serverFunction, 1000);
        })
      }
      else
        $state.go('errorPage')
    };

    $scope.loginFunction=function(username,password){
        var username = username;
        var pword = password;
        var key = CryptoJS.enc.Utf8.parse('cca2016Cognizant');
                      var iv = CryptoJS.enc.Utf8.parse('Cognizant2016cca');
                      var encryptedpassword = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(pword), key, {
                          keySize: 128 / 8,iv: iv,
                          mode: CryptoJS.mode.CBC,
                          padding: CryptoJS.pad.Pkcs7
                      });
                      pword = encryptedpassword.ciphertext.toString(CryptoJS.enc.Base64);
                      // pword = encodeURIComponent(pword);
        var userObj={
        'Password':pword ,
        'UserName':username
        };
       $http.post("https://commandcenterservice.cognizant.com/api/UserAccount/Login",userObj)
                .success(function (result) {
                  console.log(result)
                  userDetails.inputDeatils(result);
                  token = result.AuthenticationToken;
                  if(result.IsValidUser==true){
                    $state.go('welcomePage');
                  }

                  }).error(function(err){
                    if(err.ExceptionMessage.trim()=="An operations error occurred.")
                      $scope.error = "Associate ID or Password is required !!";
                    else
                      $scope.error = "Associate ID or Password is Incorrect !!";
                });

  }
  $scope.resetFunction = function(){
    $scope.username = '';
    $scope.password = '';
    $scope.error = '';
  }
});
angular.module('App')
.controller('WelcomeController',function($scope,$state,GetNameService,angularLoad,$http,$compile,$timeout,$mdDialog){
  if(token==''){
    $state.go('login');
  }
$scope.route=function(option){
  if(option=="solution")
    $state.go('solution.home')
  else if(option=="process")
      $state.go('process.processCarouselPage')
  else
      $state.go('bot')
  }
});
