var tableTemplate="";
angular.module('App')
.controller('processController',function($scope,$state,sharedURL,GetNameServiceProcess,angularLoad,$http,$compile,$timeout,userDetails){
    $scope.userName=userDetails.requiredDeails('Name');

  if(token==''){
    $state.go('login');
  }
  $scope.sortType     = 'Process'; // set the default sort type
  $scope.sortReverse  = false;  // set the default sort order
  $scope.searchFish   = '';     // set the default search/filter term
  $scope.myInterval = 1800;


  $scope.hoverEdit="md-whiteframe-10dp";
  $http.get(sharedURL.getURLProcess()+'/verticals').then(function(result) {
      $scope.verticalsList = JSON.parse(result.data)[0];
      $scope.verticalsList.sort();
    });
  $scope.hoverIn = function(){
    this.hoverEdit = "md-whiteframe-20dp , cursor";
  };

  $scope.hoverOut = function(){
    this.hoverEdit = "md-whiteframe-10dp";
  };
  $http({
          method: "GET",
          url: sharedURL.getURLProcess()+"/overallsummary",
      }).then(function(result){
        $scope.overallSummary = ($scope.overallSummary/1000000);
        $scope.overallSummary=JSON.parse(result.data)[0];

       });
  $scope.filterSearchData="false";
  $scope.isDisabled = false;
  $scope.noCache = false;
  $scope.selectedItem = undefined;
  $scope.searchText = "";
  $scope.text = '';
  $scope.searchArray = ['Vertical', 'Process or Sub Process', 'Nature of solution', 'Name of technology solution', 'Customer Implementation'];
  // $scope.fields=  [{"name":"Domains","color":'#A3E4D7'},{"name":"Verticals","color":'#5DADE2'}, {"name":"Accounts","color":'#B2BABB'}];
  $scope.fields=  [{"name":"Domains","color":'#806bd6'},{"name":"Verticals","color":'#ffdf96'},{"name":"Accounts","color":'#21a786'}];

  $scope.searchArray2 = ['Process or Sub Process', 'Nature of solution', 'Name of technology solution', 'Customer Implementation'];
  $scope.accountStage = ['Accounts','Domain','Table'];
  $scope.searchLegendFormart=['Domain','Vertical','Account' ]
  $scope.breadCrumArray = [{
      'name': 'Vertical',
      'zoom': ''
  }];
  $scope.searchBreadcrumDisplyObj={
    'Name of technology solution':'Tools',
    'Vertical':'Verticals',
    'Customer Implementation':'Accounts',
    'Process or Sub Process':'Process',
    'Nature of solution':'Solutions'
  };
  $scope.nodeStage="";
  $scope.AccountsLegendArray=[{'name':'Accounts','color':'#0fd09b'},{'name':'Process','color':'#0fd1da'},{'name':'Solutions','color':'#d6eb5b'},{'name':'Tools','color':'#fafafa'}];
  $scope.leafDeatilsArray=[];
  $scope.selectedOption=[];
  $scope.selectedItemChange = function(item) {
    if ($scope.selectedItem)
        $scope.text = $scope.selectedItem;
  }
  $scope.searchTextChange = function(str) {
      return GetNameServiceProcess.getName(str);
  }
  $scope.industries=function(){
    $state.go('process.processCarouselPage');
  }

  $scope.accountsView = function(industry) {
    $state.go('process.processAccountsPage');
    $scope.loadCircularBar=true;
    angularLoad.loadScript('js/v4.js').then(function() {
        angularLoad.loadScript('js/tooltip.js').then(function() {
      var query = "match (a:PrsCtlg_NonDistinct)-[:SubDomain]->(b:PrsCtlg_NonDistinct)-[:Vertical]->(c:PrsCtlg_NonDistinct{name:'"+industry+"'})-[:Account]->(d:PrsCtlg_NonDistinct)-[:Process]->(e:PrsCtlg_NonDistinct)  WITH a,b,c,d,e,collect( distinct {name: a.name, size:'2000'}) AS domain WITH a,b,c,d,e,collect( distinct {name: d.name, children: domain, size:'2000'}) AS Accounts  return collect(distinct {name:c.name,children:Accounts})";
      $http({
              method: "GET",
              url: sharedURL.getURLProcess()+"/summary",
              params: {
                  verticalName : industry,
              }
          }).then(function(result){
            $scope.accountSummary=JSON.parse(result.data);

            $scope.accountSummary.VerticalOverall[0].name=industry;
          });
      $http({
              method: "GET",
              url: sharedURL.getURLProcess()+"/getRelationData",
              params: {
                  paramValue : industry
              }
          }).then(function(result){
            result.data=JSON.parse(result.data);
                if (result.data[0] == undefined) {
                    $scope.completeJson = result.data;
                } else {
                    $scope.completeJson = result.data[0];
                }
                $scope.selectedOption=[];
                $scope.breadCrumArray = [{
                    'name': 'Vertical',
                    'zoom': ''
                }];
                $scope.leafDeatilsArray=[];
                $scope.accountBreadCrum({'data':{'name':industry,'stage':'Vertical'}});
                $scope.loadCircularBar=false;

          });
  });
});
}
$scope.modalTable=function(parentNodesData){
  // parentNodesData=parentNodesData.reverse();
  tableTemplate='<div class="container"><table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%"><thead style=font-size:13px><tr><th>Process</th><th>SubProcess</th><th>AHT (mins)</th><th>Volume (monthly)</th><th>FTE</th><th>Automation Opportunity(FTE)</th></tr></thead><tbody>';
  $http({
          method: "GET",
          url: sharedURL.getURLProcess()+"/accountdetails",
          params: {
              domain  : parentNodesData[2],
              vertical : parentNodesData[0],
              account   : parentNodesData[1]
          }
      }).then(function(result){

          result.data=JSON.parse(result.data);
           $scope.tableInfo = JSON.parse(result.data['AccountDetails']);
           for(var i=0;i<$scope.tableInfo.length;i++){
             tableTemplate+="<tr style='font-size:13px'><td>"+$scope.tableInfo[i]['Process']+"</td><td>"+$scope.tableInfo[i]['SubProcess']+"</td><td>"+$scope.tableInfo[i]['AHT']+"</td><td>"+$scope.tableInfo[i]['Volume']+"</td><td>"+$scope.tableInfo[i]['FTE']+"</td><td>"+$scope.tableInfo[i]['FTEBenefit']+"</td></font></tr>";
           }
           tableTemplate+="</tbody></table>";
           var element = document.getElementsByClassName("insertTableHere");
           angular.element(element[0]).html("");
           var htmlText = $compile(tableTemplate)($scope);
           angular.element(element).append(htmlText);
           $('#example').DataTable();
      });

  $('#dialog_confirm_map').modal('show');
      $('.modal-backdrop').appendTo('.bigform-content');
  $('#dialog_confirm_map').on('hidden.bs.modal', function () {
    $scope.zoom($scope.breadCrumArray[2]);
    $scope.filterBreadCrum($scope.breadCrumArray[2],$scope.breadCrumArray[1])
  });
}
// $scope.displayTable=true;

    $scope.accountBreadCrum = function(node){
      $scope.selectedAccountSemmary=$scope.accountSummary
      tempArr = [{
          'name': 'Industry',
          'zoom': ''
      }];
      if (node.data.stage == 'Vertical') {
          tempArr.push({
              'name': 'Accounts',
              'zoom': ''
          });
          $scope.selectedOption.push(node.data.name);
      } else {
        if(node.depth < $scope.breadCrumArray.length-1){
          $scope.breadCrumArray.length = node.depth;
        }
        var length = $scope.breadCrumArray.length;
          $scope.selectedOption = [];
          for (var i = 0; i <node.depth+1; i++) {
              var detail = "node";
              var parent = "node";
              for (var j = node.depth; j > i; j--) {
                  detail += ".parent";
                  parent += ".parent";
              }
              tempArr.push({
                  'name': $scope.accountStage[i],
                  'zoom': eval(parent)
              });
              $scope.selectedOption.push(eval(detail + ".data.name"));

          }
          tempArr.length = length+1;
          $scope.selectedOption.length =length;
          if($scope.breadCrumArray.length<3){

            $scope.zoom(tempArr[length]);
          }else if($scope.breadCrumArray.length==3){
          $scope.tableSummary();
            $scope.modalTable($scope.selectedOption);
          }
      }
      if (!$scope.$$phase) {
          $scope.$apply(function() {
              $scope.selectedOption;
              $scope.breadCrumArray = tempArr;
          });
      } else {
          $scope.selectedOption;
          $scope.breadCrumArray = tempArr;
      }
      return "howdy"
    }
    $scope.tableSummary =function(){
      $scope.tablePopUp={};

      for(var key in $scope.accountSummary.Domain ){
        if($scope.accountSummary.Domain[key].Account==$scope.selectedOption[1] && $scope.accountSummary.Domain[key].Domain==$scope.selectedOption[2])
        {
          $scope.tableSummaryInfo=$scope.accountSummary.Domain[key]
        }
      }

    }
    $scope.filterBreadCrum =function(node,state){
      if(state.name=="Process"){
        $scope.breadCrumArray.length=$scope.stage.indexOf(node.name)+2;
        $scope.selectedOption.length = $scope.stage.indexOf(node.name)+1;
      }else if(state.name=="Accounts"){
        $scope.breadCrumArray.length=$scope.accountStage.indexOf(node.name)+2;
        $scope.selectedOption.length = $scope.accountStage.indexOf(node.name)+1;

      };

          if (!$scope.$$phase) {
              $scope.$apply(function() {
                  $scope.selectedOption;
                  $scope.breadCrumArray;
              });
          } else {

              $scope.selectedOption;
              $scope.breadCrumArray;
          }
    }

  $scope.selectedAccount=function(account){
    $scope.accountsDisplay=account.name;
    $scope.solutionsList=[];
    for(var i=0;i<$scope.completeJson.children[account.index].children.length;i++){
      $scope.solutionsList.push({'name':$scope.completeJson.children[account.index].children[i].name,'index':i,'children':$scope.completeJson.children[account.index].children[i].children});
    }
  }
  $scope.choosenSolution=function(solution){
    $scope.selectedDisplay=solution.name;
    $scope.processList=[];
    for(var i=0;i<solution.children.length;i++){
      $scope.processList.push({'name':solution.children[i].name,'children':solution.children[i].children})
    }
  }

  $scope.specificSearch = function(text) {

    $scope.nodeStage=text.stage
    $state.go('process.processSearch');
    $scope.loadCircularBar=true;
    angularLoad.loadScript('js/v3.js').then(function() {
          angularLoad.loadScript('js/tooltip.js').then(function() {
            $scope.tempSearchArr = JSON.stringify($scope.fields);
            $scope.tempSearchArr = JSON.parse($scope.tempSearchArr);
            var index = $scope.searchLegendFormart.indexOf(text.stage);
            var swap = $scope.tempSearchArr[index];
            $scope.tempSearchArr.splice(index, 1);
            $scope.tempSearchArr.unshift(swap);

              var resultFormat=['Domain','SubDomain','Vertical','Account','Process'];
              var returnFormat=['Domain','Vertical','Account'];
              var index = returnFormat.indexOf(text.stage);
              var swap = returnFormat[index];
              returnFormat.splice(index, 1);
              returnFormat.unshift(swap);
              $scope.searhBreadCrumArray=[];
              var i= returnFormat.indexOf('Vertical');
              returnFormat[i]="Industry"
              $scope.searhBreadCrumArray=returnFormat;
                    $http({
                        method: "GET",
                        url: sharedURL.getURLProcess()+"/getGraphRelationData",
                        params: {
                            paramName : text.stage,
                            paramValue : text.name
                        }
                    }).then(function(result){

                          $scope.completeJsonSearch = JSON.parse(result.data)[0];
                          var element = document.getElementsByClassName("appendSearch");
                          angular.element(element[0]).html("");
                          var element = document.getElementsByClassName("appendSearch");
                          var htmlText = $compile("<processsearch layout='row' style='width:100%' object='{{completeJsonSearch}}' fields='{{tempSearchArr}}'> </processsearch>")($scope);
                          $scope.loadCircularBar=false;
                          angular.element(element).append(htmlText);

                    });
        });
      });
    }

    $scope.slides_tiles=[];
    $http.get(sharedURL.getURLProcess()+'/verticalAndDomains').then(function(result) {
      var parse = JSON.parse(result.data);
      var verticals = [];
      var obj = {'vertical':'','domain':[],'id':''};
      $scope.slides_tiles = [];
       for (var i = 0; i < parse.length; i++) {
       if(verticals.indexOf(parse[i].vertical)>=0)
            continue;
        else
            verticals.push(parse[i].vertical);
      }verticals.sort();
    for (var i = 0; i <verticals.length; i++){
      obj = {'vertical':'','domain':[],'id':''};
     for (var j = 0; j <parse.length; j++){
      if(parse[j].vertical==verticals[i]){
          obj.vertical = verticals[i];
          obj.domain = parse[j].domain;
          obj.id = i;
          obj.image = verticals[i]+'.png';

        }

      }
        obj['domain'].sort();
       $scope.slides_tiles.push(obj);
}
})

$scope.populateTreeTable=function(node){
  var parentNodesData=[];

  $scope.returnFormat=['Domain','Vertical','Account'];
  var index = $scope.returnFormat.indexOf($scope.nodeStage);

  var swap = $scope.returnFormat[index];
  $scope.returnFormat.splice(index, 1);
  $scope.returnFormat.unshift(swap);

  for(var i=0;i<node.depth;i++){
        var detail = "node";
        var parent = "node";
        for (var j = node.depth; j > i; j--) {
            detail += ".parent";
            parent += ".parent";
        }
        parentNodesData.push(eval(parent+".name"));
  }
  parentNodesData.push(node.name);
    $scope.parentNodesData=parentNodesData;
    $http({
            method: "GET",
            url: sharedURL.getURLProcess()+"/accountdetails",
            params: {
                domain : parentNodesData[$scope.returnFormat.indexOf('Domain')],
                vertical : parentNodesData[$scope.returnFormat.indexOf('Vertical')],
                account : parentNodesData[$scope.returnFormat.indexOf('Account')]
            }
        }).then(function(result){
          $scope.treeSummaryInfo={};
          result.data=JSON.parse(result.data);
          tableTemplate='<div class="container"><table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%"><thead style=font-size:13px> <tr><th>Process</th><th>SubProcess</th><th>AHT (mins)</th><th>Volume (monthly)</th><th>FTE</th><th>Automation Opportunity (FTE)</th></tr></thead><tbody>';

                     $scope.tableInfo = JSON.parse(result.data['AccountDetails']);
                     for(var i=0;i<$scope.tableInfo.length;i++){
                       tableTemplate+="<tr style='font-size:13px'><td>"+$scope.tableInfo[i]['Process']+"</td><td>"+$scope.tableInfo[i]['SubProcess']+"</td><td>"+$scope.tableInfo[i]['AHT']+"</td><td>"+$scope.tableInfo[i]['Volume']+"</td><td>"+$scope.tableInfo[i]['FTE']+"</td><td>"+$scope.tableInfo[i]['FTEBenefit']+"</td></tr>";
                     }
                     tableTemplate+="</tbody></table>";

                     var element = document.getElementsByClassName("insertTableHere");
                     angular.element(element[0]).html("");
                     var htmlText = $compile(tableTemplate)($scope);
                     angular.element(element).append(htmlText);
                     $('#example').DataTable();
                     $('#dialog_confirm_map').modal('show');
                     $('.modal-backdrop').appendTo('.bigform-content');
                     if (!$scope.$$phase) {
                         $scope.$apply(function() {
                                $scope.treeSummaryInfo=JSON.parse(result.data['AccountSummary'])[0];
                         });
                     } else {
                                $scope.treeSummaryInfo=JSON.parse(result.data['AccountSummary'])[0];
                     }

                });


}
  $scope.selectedDomain=function(domain){
    $scope.loadCircularBar=true;
    $state.go('process.processSearch');
    $scope.nodeStage="Domain";
    angularLoad.loadScript('js/v3.js').then(function() {
        angularLoad.loadScript('js/tooltip.js').then(function() {
              $http({
                      method: "GET",
                      url: sharedURL.getURLProcess()+"/getGraphRelationData",
                      params: {
                          paramName : "Domain",
                          paramValue : domain
                      }
                  }).then(function(result){

                              $scope.Solutionsfields=  [{"name":"Domains","color":'#806bd6'},{"name":"Verticals","color":'#ffdf96'},{"name":"Accounts","color":'#21a786'}];
                              $scope.completeJsonDomain = JSON.parse(result.data)[0];
                              var element = document.getElementsByClassName("appendSearch");
                              angular.element(element[0]).html("");
                              $scope.loadCircularBar=false;
                              var element = document.getElementsByClassName("appendSearch");
                              var htmlText = $compile("<processsearch layout='row' layout-align='center center' object='{{completeJsonDomain}}' fields='{{Solutionsfields}}'> </processsearch>")($scope);
                              angular.element(element).append(htmlText);
                              $scope.searhBreadCrumArray=['Domain','Industry','Account']
                  });
        });
      });
  }
  $scope.logoClick = function(){
    $state.go('process.processCarouselPage');
    $scope.text = '';
  }


});
