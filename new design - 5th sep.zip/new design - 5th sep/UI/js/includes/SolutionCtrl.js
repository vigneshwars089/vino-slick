var token = '';
angular.module('App')
  .controller('Controller',function($scope, $state, $mdToast, sharedURL, GetNameService,angularLoad,$http,$compile,$timeout, $stateParams,userDetails){
    $scope.userName=userDetails.requiredDeails('Name');

  $scope.top_tools = [];
      if(token==''){
        $state.go('login');
      }
  $scope.logoClick = function(){
    $state.go('solution.home');
    $scope.text = '';
  }

    $http.get(sharedURL.getURL()+'/top/Name_of_technology_solution/',{headers:  {
            'AuthorizationToken': token
          }}).then(function(result){
                $scope.top_tool = result.data[0];
                $scope.top_tool_year = result.data[1];
          });

  $scope.correctData={
    'yearOfLaunch':'Year of Launch',
    'implementationApproach':'Implementation Approach',
    'ownership':' Ownership',
    'totalEcternalClients':'Total External Clients',
    'solutionHosting':'Solution Hosting'
  }
  $scope.solution_catalog = function(){
    $state.go('solution.home')
  }



  $scope.conceptMap=function(){
      $state.go('solution.conceptMap')
  }
  $http.get(sharedURL.getURL()+'/List/solutions',{headers:  {
          'AuthorizationToken': token
        }}).then(function(result) {
      $scope.solutions = result.data;
      $scope.solutions.sort();
      $scope.myInterval = 1800;
      $scope.noWrapSlides = false;
      $scope.active = 0;
      var slides = $scope.slides = [];
      var currIndex = 0;
      $scope.addSlide = function(i) {
        var newWidth = 600 + $scope.solutions.length + 1;
        slides.push({
          image: '//unsplash.it/'+newWidth+'/300',
          text: $scope.solutions[i],
          id: currIndex++
        });
      };
      for (var i = 0; i < $scope.solutions.length; i++) {
        $scope.addSlide(i);
      }
  });

  $scope.hoverEdit="md-whiteframe-10dp";

  $http.get(sharedURL.getURL()+'/List/verticals',{headers:  {
          'AuthorizationToken': token
        }}).then(function(result) {
      $scope.verticalsList = result.data;
      $scope.verticalsList.sort();
  });
  $scope.hoverIn = function(){
    this.hoverEdit = "md-whiteframe-20dp , cursor";
  };

  $scope.hoverOut = function(){
    this.hoverEdit = "md-whiteframe-10dp";
  };

  $scope.isDisabled = false;
  $scope.noCache = false;
  $scope.selectedItem = undefined;
  $scope.searchText = "";
  $scope.text = '';
  $scope.searchArray = ['Vertical', 'Process or Sub Process', 'Nature of solution', 'Name of technology solution', 'Customer Implementation'];
  // $scope.fields=  [{"name":"Verticals","color":'#A3E4D7'},{"name":"Accounts","color":'#B2BABB'}, {"name":"Processes","color":'#5DADE2'} , {"name":"Solutions","color":'#C39BD3'},{"name":"Tools","color":'#F0B27A'}];
  $scope.fields=  [{"name":"Verticals","color":'#ffdf96'},{"name":"Accounts","color":'#21a786'}, {"name":"Processes","color":'#806bd6'} , {"name":"Solutions","color":'#79f1f7'},{"name":"Tools","color":'#ff80ab'}];

  $scope.searchArray2 = ['Process or Sub Process', 'Nature of solution', 'Name of technology solution', 'Customer Implementation'];
  $scope.accountStage = ['Accounts','Process', 'Solution', 'Tools'];
  $scope.searchLegendFormart=['Vertical',  'Customer Implementation','Process or Sub Process', 'Nature of solution', 'Name of technology solution']
  $scope.breadCrumArray = [{
      'name': 'Industry',
      'zoom': ''
  }];
  $scope.searchBreadcrumDisplyObj={
    'Name of technology solution':'Tools',
    'Vertical':'Industries',
    'Customer Implementation':'Accounts',
    'Process or Sub Process':'Process',
    'Nature of solution':'Solutions'
  };
  $scope.AccountsLegendArray=[{'name':'Accounts','color':'#0fd09b'},{'name':'Process','color':'#0fd1da'},{'name':'Solutions','color':'#d6eb5b'},{'name':'Tools','color':'#fafafa'}];
  $scope.leafDetailsArray=[];
  $scope.selectedOption=[];
  $scope.selectedItemChange = function(item) {
    if ($scope.selectedItem)
        $scope.text = $scope.selectedItem;
  }
  $scope.searchTextChange = function(str) {
      return GetNameService.getName(str);
  }
  $scope.industries=function(){
    $state.go('solution.home');
    $scope.leafDetailsArray=[];
  }
  $scope.selectedIndustry=function(data){
    // $scope.leafDetailsArray.length=0;
    $scope.accountsArray=[];
    $scope.processList=[];
    $scope.solutionsList=[];
    $scope.verticalDisplay=data;
    var query="match (a:tools2{name:'"+data+"'})-[:Process_or_Sub_Process]->(b:tools2)-[:Nature_of_solution]->(c:tools2)-[:Name_of_technology_solution]->(d:tools2)-[:Customer_Implementation]->(e:tools2) with a,b,c,d,e match (d)-[:Ownership]->(f:tools2),(d)-[:Year_of_launch]->(g:tools2),(d)-[:Total_number_of_external_clients]->(h:tools2),(d)-[:Implementation_approach]->(i:tools2),(d)-[:Solution_hosting]->(j:tools2) with a,b,c,d,e,f,g,h,i,j,collect( distinct {ownership:f.name,yearOfLaunch:g.name,totalEcternalClients:h.name,implementationApproach:i.name,solutionHosting:j.name}) as leaf with a,b,c,d,e,f,g,h,i,j,collect( distinct {name:d.name,children:leaf})as tools with a,b,c,d,e,f,g,h,i,j,collect( distinct {name:b.name,children:tools})as process with a,b,c,d,e,f,g,h,i,j,collect( distinct {name:c.name,children:process})as solutions with a,b,c,d,e,f,g,h,i,j,collect( distinct {name:e.name,children:solutions})as accounts return collect( distinct {name:a.name,children:accounts})"
      $http.get(sharedURL.getURL()+'/get/getData/'+query,{headers:  {
            'AuthorizationToken': token
          }}).then(function(result){
      $scope.completeJson=result.data;
      for(var i=0;i<result.data.children.length;i++){
        $scope.accountsArray.push({'name':result.data.children[i].name,'index':i});
      }
      $state.go('solution.accountsList');
    });
  }
  $scope.accountsView = function(industry) {
    $state.go('solution.accountsList');
    $scope.loadCircularBar=true;
    angularLoad.loadScript('js/v4.js').then(function() {
        angularLoad.loadScript('js/tooltip.js').then(function() {
      var query = "match (a:tools2{name:'"+industry+"'})<-[:Vertical]-(b:tools2)<-[:Customer_Implementation]-(c:tools2)<-[:Name_of_technology_solution]-(d:tools2)<-[:Nature_of_solution]-(e:tools2) WITH a, b,c,d,e, collect( distinct {name: c.name, size:'2000'}) AS tools WITH a,b,c,d,e,collect( distinct {name: d.name, children: tools, size:'2000'}) AS solutions WITH a,b,c,d,e,collect( distinct {name: e.name, children: solutions, size:'2000'}) AS process WITH a,b,c,d,e,collect( distinct {name: b.name, children: process,size:'2000'}) AS customers return collect(distinct {name:a.name,children:customers}) ";
      var postObj = {
        'route':'',
        'query':query
      }
      $http.post(sharedURL.getURL()+'/get',postObj,{headers:  {
              'AuthorizationToken': token
            }}).then(function(result) {
          if (result.data[0] == undefined) {
              $scope.completeJson = result.data;
          } else {
              $scope.completeJson = result.data[0]._fields[0];
          }

          $scope.selectedOption=[];
          $scope.breadCrumArray = [{
              'name': 'Industry',
              'zoom': ''
          }];
          $scope.leafDetailsArray=[];
          $scope.accountBreadCrum({'data':{'name':industry,'stage':'Vertical'}});
          $scope.loadCircularBar=false;
      });
  });
});
}
$scope.displayLeafDetails=function(node){
  $scope.loadDetails=true;
  $scope.leafDetailsArray=[];
  var query="node"
  var tempArr=[]
  for(var i=0;i<4;i++){
    query+=".parent";
    tempArr.push(eval(query+".data.name"))
  }
  $scope.displayTool=node.data.name;
  $scope.displaySoluton=tempArr[0];
  var neoQuery="match (a:tools2{name:'"+tempArr[3]+"'})-[:Process_or_Sub_Process]->(b:tools2{name:'"+tempArr[1]+"'})-[:Nature_of_solution]->(c:tools2{name:'"+tempArr[0]+"'})-[:Name_of_technology_solution]->(d:tools2{name:'"+node.data.name+"'})-[:Customer_Implementation]->(e:tools2{name:'"+tempArr[2]+"'}) with a,b,c,d,e match (d)-[:Ownership]->(f:tools2),(d)-[:Year_of_launch]->(g:tools2),(d)-[:Total_number_of_external_clients]->(h:tools2),(d)-[:Implementation_approach]->(i:tools2),(d)-[:Solution_hosting]->(j:tools2) return collect( distinct {ownership:f.name,yearOfLaunch:g.name,totalEcternalClients:h.name,implementationApproach:i.name,solutionHosting:j.name})";
  // if(neoQuery.indexOf('/')){
  //   neoQuery=neoQuery.replace('/','_hashhere_');
  // }
  var postObj = {
    'query':neoQuery
  }
  $http.post(sharedURL.getURL()+"/leafDetails/",postObj,{headers:  {
          'AuthorizationToken': token
        }}).then(function(result){
            $scope.leafDetailsArray=[];
    for(var key in result.data[0]){
        $scope.leafDetailsArray.push({'name':key,'value':result.data[0][key]})
    }
    $scope.loadDetails=false;
  });
}
    $scope.accountBreadCrum = function(node){
      tempArr = [{
          'name': 'Industry',
          'zoom': ''
      }];
      if (node.data.stage == 'Vertical') {
            tempArr.push({
              'name': 'Accounts',
              'zoom': ''
          });
          $scope.selectedOption.push(node.data.name);
      } else {
        if(node.depth < $scope.breadCrumArray.length-1){
          $scope.breadCrumArray.length = node.depth;
        }
        var length = $scope.breadCrumArray.length;
          $scope.selectedOption = [];
          for (var i = 0; i < node.depth + 1; i++) {
              var detail = "node";
              var parent = "node";
              for (var j = node.depth; j > i; j--) {
                  detail += ".parent";
                  parent += ".parent";
              }
              tempArr.push({
                  'name': $scope.accountStage[i],
                  'zoom': eval(parent)
              });
              $scope.selectedOption.push(eval(detail + ".data.name"))
          }
          tempArr.length = length+1;
          $scope.selectedOption.length = length;
          $scope.zoom(tempArr[length]);
      }
      if (!$scope.$$phase) {
          $scope.$apply(function() {
              $scope.selectedOption;
              $scope.breadCrumArray = tempArr;
          });
      } else {

          $scope.selectedOption;

          $scope.breadCrumArray = tempArr;
      }
      return "howdy"
    }
    $scope.filterBreadCrum =function(node,state){
      if(state.name=="Process"){
        $scope.breadCrumArray.length=$scope.stage.indexOf(node.name)+2;
        $scope.selectedOption.length = $scope.stage.indexOf(node.name)+1;
      }else if(state.name=="Accounts"){
        $scope.breadCrumArray.length=$scope.accountStage.indexOf(node.name)+2;
        $scope.selectedOption.length = $scope.accountStage.indexOf(node.name)+1;

      };

          if (!$scope.$$phase) {
              $scope.$apply(function() {
                  $scope.selectedOption;
                  $scope.breadCrumArray;
              });
          } else {

              $scope.selectedOption;
              $scope.breadCrumArray;
          }
    }

  $scope.selectedAccount=function(account){
    $scope.accountsDisplay=account.name;
    $scope.solutionsList=[];
    for(var i=0;i<$scope.completeJson.children[account.index].children.length;i++){
      $scope.solutionsList.push({'name':$scope.completeJson.children[account.index].children[i].name,'index':i,'children':$scope.completeJson.children[account.index].children[i].children});
    }
  }
  $scope.choosenSolution=function(solution){
    $scope.selectedDisplay=solution.name;
    $scope.processList=[];
    for(var i=0;i<solution.children.length;i++){
      $scope.processList.push({'name':solution.children[i].name,'children':solution.children[i].children})
    }
  }
  $scope.specificSearch = function(text) {
    $scope.searchStage = text.stage;
    $state.go('solution.search');
    $scope.loadCircularBar=true;
    angularLoad.loadScript('js/v3.js').then(function() {
          angularLoad.loadScript('js/tooltip.js').then(function() {
            $scope.tempSearchArr = JSON.stringify($scope.fields);
            $scope.tempSearchArr = JSON.parse($scope.tempSearchArr);
            var index = $scope.searchLegendFormart.indexOf(text.stage);
            var swap = $scope.tempSearchArr[index];
            $scope.tempSearchArr.splice(index, 1);
            $scope.tempSearchArr.unshift(swap);
              var resultFormat=['Vertical','Customer Implementation','Process or Sub Process', 'Nature of solution', 'Name of technology solution'];
              var index = resultFormat.indexOf(text.stage);
              var swap = resultFormat[index];
              resultFormat.splice(index, 1);
              resultFormat.unshift(swap);
              $scope.searhBreadCrumArray=[];
              $scope.searhBreadCrumArray=resultFormat;
              var query="MATCH"
              for(var i=0;i<$scope.searchArray.length;i++){
                if ($scope.searchArray.indexOf(text.stage) != i) {
                  if ($scope.searchArray2[i] != undefined) {
                    query += "(n" + i + ":tools2)-[:" + $scope.searchArray2[i].replace(/ /g, "_") + "]->";
                  }else{
                     query += "(n" + i + ":tools2)";
                  }
                }else{
                  if ($scope.searchArray2[i] != undefined) {
                    query += "(n" + i + ":tools2{name:'"+text.name+"'})-[:" + $scope.searchArray2[i].replace(/ /g, "_") + "]->";
                  }else{
                     query += "(n" + i + ":tools2{name:'"+text.name+"'})";
                  }
                }
              }
              var count=0
              var endQuery="";
              for(var i=resultFormat.length-1;i>0;i--){
                if(i==resultFormat.length-1){
                   endQuery += " with n0,n1,n2,n3,n4,collect(distinct{name:n"+$scope.searchArray.indexOf(resultFormat[i])+".name}) as a"+count;
                   count++;
                }
                else{
                  endQuery += " with n0,n1,n2,n3,n4,collect(distinct{name:n"+$scope.searchArray.indexOf(resultFormat[i])+".name,children:a"+(count-1)+"}) as a"+(count);
                  count++;
                }
              }
              var returnQuery=" RETURN collect( distinct{name:n"+$scope.searchArray.indexOf(resultFormat[0])+".name,children:a"+(count-1)+"})"
              var finalQuery=query+endQuery+returnQuery;
              var postObj={
                  'route':'getData',
                  'query':finalQuery
                };
              $http.post(sharedURL.getURL()+'/get',postObj,{headers:  {
                        'AuthorizationToken': token
                      }}).then(function(result) {

                    $scope.completeJsonSearch = result.data;
                    var element = document.getElementsByClassName("appendSearch");
                    angular.element(element[0]).html("");
                    var element = document.getElementsByClassName("appendSearch");
                    var htmlText = $compile("<search layout='row' style='width:100%' object='{{completeJsonSearch}}' fields='{{tempSearchArr}}'> </search>")($scope);
                    $scope.loadCircularBar=false;
                    angular.element(element).append(htmlText);
                });
        });
      });
    }


    $scope.callConceptFunction=function(){
      var toolName = '';
      toolName = $stateParams.toolName;
      $scope.toolNamecheck = false;
      $scope.conceptMapDiv1 = false;
      $scope.conceptMapDiv2 = false;
      $scope.conceptMapDiv3 = false;
      $scope.conceptMapDiv4 = false;
      $scope.loadBar = true;


      $scope.concept_tools = [];
          angularLoad.loadScript('js/v3.js').then(function() {
            $http.get(sharedURL.getURL()+'/concept',{headers:  {
                    'AuthorizationToken': token
                  }}).then(function(result) {
                      for(i=0;i<result.data.length;i++){
                          result.data[i][0] = result.data[i][0].charAt(0).toUpperCase() + result.data[i][0].slice(1);
                          if($scope.concept_tools.indexOf(result.data[i][0].charAt(0)) < 0){
                              $scope.concept_tools.push(result.data[i][0].charAt(0));
                            }
                          }
                $scope.concept_tools.sort();
                $scope.concept_tools_obj = {};
                $scope.concept_tools_arr = [];
                for(var i = 0; i < $scope.concept_tools.length; i++)
                {
                  $scope.concept_tools_obj = {};
                  $scope.concept_tools_obj['name'] = $scope.concept_tools[i];
                  $scope.concept_tools_obj['selected'] = false;
                  $scope.concept_tools_arr.push($scope.concept_tools_obj);
                }

                if(toolName != "")
                {
                  $scope.toolName = toolName;
                  $scope.toolNamecheck = true;
                  drawConceptMap(result,  $scope.toolName);
                }
                else{
                  $scope.toolNamecheck = false;
                  drawConceptMap(result,$scope.top_tool);
                }

                $scope.header = "Tools start with";
                $scope.url = document.URL;
            })
          });
      }
      $scope.displayTerm = function(term){
          for(var i = 0; i < $scope.concept_tools_arr.length; i++){
            var item = $scope.concept_tools_arr[i];

            if(item.name == term){
                      item.selected = !item.selected;

            }else {
                item.selected = false;
            }
        }
        $scope.division = '';
        var div1 = ["A","B","C"];
        var div2 = ["D","E","F","G","H"];
        var div3 = ["I","J","K","L","M","N","O","P","Q"];

        var conceptName = 'conceptMapDiv';

        if( (div1.indexOf(term))>=0)
          $scope.division = conceptName+"1";
        else if( (div2.indexOf(term))>=0)
          $scope.division = conceptName+"2";
        else if( (div3.indexOf(term))>=0)
          $scope.division = conceptName+"3";
        else
          $scope.division = conceptName+"4";


          for(i=1;i<=4;i++)
          {
            if($scope.division == conceptName+i){
              $scope[conceptName+i] = true;
            }
            else {
              $scope[conceptName+i] = false;
            }
          }
         update(term);
        }

  $scope.selectedSolution=function(solution){
    $state.go('solution.search');
    $scope.loadCircularBar=true;
    angularLoad.loadScript('js/v3.js').then(function() {
        angularLoad.loadScript('js/tooltip.js').then(function() {
          // var route="";
          // if(solution.text.indexOf('/')){
          //   solution.text=solution.text.replace('/','_hashhere_');
          //   route="getSolutions"
          // }else{
            route='getData';
          // }
          $scope.searhBreadCrumArray=[];
          var resultFormat=['Nature of solution','Vertical','Customer Implementation','Process or Sub Process', 'Name of technology solution'];
          $scope.searhBreadCrumArray=resultFormat;
          // $scope.Solutionsfields=  [{"name":"Solutions","color":'#C39BD3'},{"name":"Verticals","color":'#A3E4D7'},{"name":"Accounts","color":'#B2BABB'}, {"name":"Processes","color":'#5DADE2'} , {"name":"Tools","color":'#F0B27A'}];
          $scope.Solutionsfields = [{'name':'Solutions','color':'#79f1f7'},{'name':'Industries','color':'#ffdf96'},{'name':'Accounts','color':'#21a786'},{'name':'Process','color':'#806bd6'},{'name':'Tools','color':'#ff80ab'}];
          var query = "match (a:tools2)-[:Process_or_Sub_Process]->(b:tools2)-[:Nature_of_solution]->(c:tools2{name:'"+solution.text+"'})-[:Name_of_technology_solution]->(d:tools2)-[:Customer_Implementation]->(e:tools2) WITH a, b,c,d,e, collect( distinct {name: d.name}) AS tools WITH a, b,c,d,e,collect( distinct {name: b.name, children:tools}) AS process WITH a, b,c,d,e,collect( distinct {name: e.name, children: process}) AS accounts WITH a, b,c,d,e,collect( distinct {name: a.name, children: accounts}) AS verticals return collect(distinct {name:c.name,children:verticals})";
          var postObj = {
            'query':query,
            'route':'getData'
          }
                  $http.post(sharedURL.getURL()+'/get',postObj,{headers:  {
                      'AuthorizationToken': token
                    }}).then(function(result) {
                  $scope.completeJsonSearch = result.data;
                  var element = document.getElementsByClassName("appendSearch");
                  angular.element(element[0]).html("");
                  var element = document.getElementsByClassName("appendSearch");
                  var htmlText = $compile("<search layout='row' style='width:100%' object='{{completeJsonSearch}}' fields='{{Solutionsfields}}'> </search>")($scope);
                  $scope.loadCircularBar=false;
                  angular.element(element).append(htmlText);

              });
        });
      });

}
});
angular.module('App')
.controller('AppCtrl', ['$interval',
    function($interval) {
      var self = this;

      self.activated = true;
      self.determinateValue = 30;

      // Iterate every 100ms, non-stop and increment
      // the Determinate loader.
      $interval(function() {

        self.determinateValue += 1;
        if (self.determinateValue > 100) {
          self.determinateValue = 30;
        }

      }, 100);
    }
  ]);
