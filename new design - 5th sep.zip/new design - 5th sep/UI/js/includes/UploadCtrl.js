angular.module('App')
.controller('DataUpload',function($scope,$state,$http,sharedURL,Upload,$window,angularLoad,$mdToast){
  $scope.isOpen = false;

$scope.demo = {
  isOpen: false,
  count: 0,
  selectedDirection: 'left'
};
  $scope.destination='Solution';
  $scope.selectedFile=undefined;
  $scope.displayText="Drag files here or click to upload";
  function triggerCallback(e, callback) {
    if(!callback || typeof callback !== 'function') {
      return;
    }
    var files;
    if(e.dataTransfer) {
      files = e.dataTransfer.files;
    } else if(e.target) {
      files = e.target.files;
    }
    callback.call(null, files);
  }
  function makeDroppable(ele, callback) {
    var input = document.createElement('input');
    input.setAttribute('type', 'file');
    input.setAttribute('multiple', false);
    input.style.display = 'none';
    input.addEventListener('change', function(e) {
      triggerCallback(e, callback);
    });
    ele.appendChild(input);

    ele.addEventListener('dragover', function(e) {
      e.preventDefault();
      e.stopPropagation();
      ele.classList.add('dragover');
    });

    ele.addEventListener('dragleave', function(e) {
      e.preventDefault();
      e.stopPropagation();
      ele.classList.remove('dragover');
    });

    ele.addEventListener('drop', function(e) {
      e.preventDefault();
      e.stopPropagation();
      ele.classList.remove('dragover');
      triggerCallback(e, callback);
    });

    ele.addEventListener('click', function() {
      input.value = null;
      input.click();
    });
  }
  window.makeDroppable = makeDroppable;
  makeDroppable(window.document.querySelector('.demo-droppable'), function(files) {
    $scope.uploaded=false;
    document.querySelector('.demo-droppable').style.backgroundColor="#31afad";
      $scope.selectedFile=files[0];
      var re = /(?:\.([^.]+))?$/
      var ext = re.exec(files[0].name)[1];
      if(!$scope.$$phase) {
        $scope.$apply(function () {
          if(ext=="xlsx" || ext=="xlsm"){
              $scope.disabled=false;
            $scope.displayText=files[0].name;
          }else{
              $scope.disabled=true;
              $scope.displayText="Invalid File Format!!"
              document.querySelector('.demo-droppable').style.backgroundColor="#ea2e2e";
          }
        });
      }else{
      if(ext=="xlsx" || ext=="xlsm"){
          $scope.disabled=false;
        $scope.displayText=files[0].name;
      }else{
          $scope.disabled=true;
          $scope.displayText="Invalid File Format!!"
          document.querySelector('.demo-droppable').style.backgroundColor="#ea2e2e";
      }
      }
  });
  $scope.showToast = function(data) {
  $mdToast.show(
    $mdToast.simple()
      .textContent(data)
      .position('bottom right')
      .hideDelay(3000)
  );
};
$scope.submit=function(){
if($scope.selectedFile==undefined){
  $scope.showToast('Please select a file to upload !!');
}else{
  $scope.loadCircularBar=true;
  vm.upload($scope.selectedFile);
}
}
  $scope.loadCircularBar=false;
  var vm = this;
  $scope.disabled=false;
  vm.submit = function(){
    if($scope.destination!=""){
      $scope.loadCircularBar=true; //function to call on form submit
        if (vm.upload_form.file.$valid && vm.file) {
            console.log(vm.file); //check if from is valid
            vm.upload(vm.file); //call upload function
        }
    }else{
      $scope.showToast('Pleast select an option !!')
    }
  }

  vm.upload = function (file) {
      $scope.seletedFileName="";
      Upload.upload({
          url: sharedURL.getURL()+'/upload', //webAPI exposed to upload the file
          data:{file:file} //pass file as data, should be user ng-model
      }).then(function (resp) { //upload function returns a promise
          if(resp.data.error_code === 0){ //validate success
              // $window.alert('Success ' + resp.config.data.file.name + 'uploaded. Response: ');
          } else {
              // $window.alert('an error occured');
          }
      }, function (resp) { //catch error
          console.log('Error status: ' + resp.status);
          // $window.alert('Error status: ' + resp.status);
      }, function (evt) {
          console.log(evt);
          var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
          console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
          vm.progress = 'progress: ' + progressPercentage + '% '; // capture upload progress
          $scope.loadCircularBar=false;
              $scope.uploaded=true;
      });
  };
  $scope.fileNameChanged = function (ele) {
    console.log(ele.files[0]);
    $scope.seletedFileName= ele.files[0].name;
    $scope.uploaded=false;
  }
  $scope.downloadSolutions =function(){
    $window.open(sharedURL.getURL()+'/download','_self');
  }
  $scope.downloadProcess =function(){
    $window.open(sharedURL.getURL()+'/downloadProcess','_self');
  }
});
