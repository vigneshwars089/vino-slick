﻿angular.module('App')
 .controller("botController", function ($scope, $state, $document, $http, userDetails, $rootScope, $timeout) {
     //if (token == '') {
     //    $state.go('login');
     //}
     $scope.tool = '';
     $scope.botMini = ['Antoine', 'Avogadro', 'Darwin', 'Mendeleev'];
     //$scope.botMiniClone = ['Antoine', 'Avogadro', 'Darwin', 'Mendeleev', 'Nobel'];
    $scope.tool = "All";
    $scope.condition = false;
    $scope.userName = userDetails.requiredDeails('GivenName');
    $scope.vertical = "Insurance";
    $scope.myInterval = 1800;
    $scope.slides_tiles = [1, 2, 3];
    $scope.cards = [1, 2, 3, 4, 5, 6];
    $scope.cardDivActive = true;
    $scope.wholeData = [
        { 
            'vertical':'Insurance',
            'serviceLine': ['All','Product Development', 'Marketing & Distribution', 'Underwriting & New Business', 'Policy Servicing', 'Claims Management', 'Shared Services'] },
        {
             'vertical': 'Life Science',
             'serviceLine': ['All', 'Clinical Data Management ', 'Clinical Operations ', 'Pharmacovigilance / Drug Safety ']
        },
        {
            'vertical': 'Technology',
            'serviceLine': ['All', 'Order Management  & Customer Care', 'Product Support 2.0', 'Store Support & Customer Care', 'Digital Marketing Operations ']
        },
        {
            'vertical':'Banking & Finance',
            'serviceLine' : ['All','Asset & Wealth Management' , 'Banking Services',' Cards','Commercial Lending','Investment Banking','Mortgage','Payments and Treasury']
        },
        {
            'vertical':'Healthcare',
            'serviceLine': ['All','Provider Network Management ', 'Pricing & Underwriting', 'Sales Administration', 'Enrollment & Billing', 'Claims', 'Customer Service', 'Financial Management', 'Reporting & Compliance ']
        },
        {
            'vertical': 'Finance & Accounting',
            'serviceLine': ['All', 'Source to Pay - Operations ', 'Order to Cash - Operations', 'Record to Report - Operations ', 'Financial Planning & Analysis - Operations', 'Procure to Pay']
        }
    ];
 
    $scope.btnClick = function (vertical) {
        $scope.condition = true;
        $scope.serviceLineArray = [];
        $scope.vertical = vertical;
        $scope.verticalChk = true;
        
        for (i = 0; i < $scope.wholeData.length;i++){
            if($scope.vertical==$scope.wholeData[i].vertical)
            {
                $scope.serviceLineArray = $scope.wholeData[i].serviceLine;
            }
        }
        $scope.serviceLine = $scope.serviceLineArray[0];
        console.log($scope.serviceLineArray)
    }

    $scope.searchFun = function () {

    }
    
  

    var arrayVerticals = ['Insurance', 'Banking & Finance', 'Life Science', 'Technology', 'Healthcare', 'Finance & Accounting'];
    $scope.toolDrop = function (tool) {
        $scope.tool = tool;
        $scope.toolChk = true;
         
    }
    $scope.serviceDrop = function () {
        
        $scope.serviceChk = true;
        if (($scope.toolChk + $scope.verticalChk + $scope.serviceChk) == 3) {
            //bots bind
            $scope.botData = [
                {
                    'tool': 'UI Path',
                    'domain': 'Healthcare',
                    'serviceLine': 'Claims',
                    'bot': 'Darwin'
                },
                {
                    'tool': 'Automation Anywhere',
                    'domain': 'Banking & Finance',
                    'serviceLine':'Claims',
                    'bot': 'Antoine'
                },
                 {
                     'tool': 'Automation Anywhere',
                     'domain': 'Banking & Finance',
                     'serviceLine': 'Banking Services',
                     'bot': 'Mendeleev'
                 },
                 {
                     'tool': 'Automation Anywhere',
                     'domain': 'Banking & Finance',
                     'serviceLine': 'Banking Services',
                     'bot': 'Priestley'
                 },
                 {
                     'tool': 'Automation Anywhere',
                     'domain': 'Banking & Finance',
                     'serviceLine': 'Banking Services',
                     'bot': 'Avogadro'
                 },
                {
                    'tool': 'Automation Anywhere',
                    'domain': 'Finance & Accounting',
                    'serviceLine': 'Source to Pay - Operations',
                    'bot': 'Curie'
                },
                 {
                     'tool': 'Automation Anywhere',
                     'domain': 'Finance & Accounting',
                     'serviceLine': 'Source to Pay - Operations',
                     'bot': 'Nobel'
                 },
                  {
                      'tool': 'Automation Anywhere',
                      'domain': 'Finance & Accounting',
                      'serviceLine': 'Source to Pay - Operations',
                      'bot': 'Pauling'
                  }
            ];
            $scope.botMini = [];
            for (i = 0; i < $scope.botData.length; i++) {
                if ($scope.tool == $scope.botData[i].tool) {
                   
                    if ($scope.vertical == $scope.botData[i].domain) {
                    
                        if ($scope.serviceLine == $scope.botData[i].serviceLine) {
                           
                            $scope.botMini.push($scope.botData[i].bot);
                        }
                       }
                    }
                }
        }
        (function () {
             
            jQuery('.carousel-showmanymoveone .item').each(function () {
                console.log('clone')
                var itemToClone = jQuery(this);
               
                for (var i = 1; i < $scope.botMini.length; i++) {
                    itemToClone = itemToClone.next();

                    //wrap around if at end of item collection
                    if (!itemToClone.length) {
                      itemToClone = $(this).siblings(':first');
                    }

                    // grab item, clone, add marker class, add to collection
                    itemToClone.children(':first-child').clone(true)
                      .addClass("cloneditem-" + (i))
                      .appendTo(jQuery(this));


                    //event handler for all cloned items
                    jQuery(document).on('click', ".cloneditem-" + (i), function () {
                        $scope.miniClick($(this).attr('id'));

                    });
                }
            });
        }());
          console.log($scope.botMini)
    }

    jQuery(document).ready(function () {
        jQuery('.dropdown-toggle').dropdown();
    });

     //BotresumeCtrl
        $scope.miniClick = function (mini) {
            $rootScope.miniClicked = mini;
            $state.go('botResume')
        }
    
     
        
 })

