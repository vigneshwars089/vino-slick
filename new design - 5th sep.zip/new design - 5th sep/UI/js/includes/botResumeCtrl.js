﻿angular.module('App')
 .controller("botResumeCtrl", function ($scope, $state, $document, $http, userDetails, $rootScope) {
     $scope.pdf = '../Assets/botresume/Darwin.pdf';
     $scope.pdfArray = ["Darwin", "Mendeleev", "Priestley"];
     $scope.pdfData = [
             { 'pdf': 'Darwin', 'src': '../Assets/botresume/Darwin.pdf', 'index': 0 },
            { 'pdf': 'Mendeleev', 'src': '../Assets/botresume/Mendeleev.pdf', 'index': 1 },
            { 'pdf': 'Priestley', 'src': '../Assets/botresume/Priestley.pdf', 'index': 2 }
     ];

     for (i = 0; i < $scope.pdfData.length; i++) {
         if ($rootScope.miniClicked == $scope.pdfData[i].pdf) {
             $scope.pdf = $scope.pdfData[i].src;
         }
     }
     //NextButtonFunction
     var count = 1; var index = 0;
     var countPrev = 1; var indexPrev = 0;
     $scope.pdfChange = function () {
             for (i = 0; i < $scope.pdfData.length; i++) {
                 if ($scope.pdf == $scope.pdfData[i].src) {
                     index = ($scope.pdfData[i].index) + 1;
                     console.log(index)
                     $scope.pdf = $scope.pdfData[index].src;
                     break;
                 }
             }
     }
     //PrevButtonFunction
     $scope.pdfChangePrev = function () {
             for (i = 0; i < $scope.pdfData.length; i++) {
                 if ($scope.pdf == $scope.pdfData[i].src) {
                     indexPrev = ($scope.pdfData[i].index) - 1;
                     if (indexPrev >= 0)
                         $scope.pdf = $scope.pdfData[indexPrev].src;
                    
                 }
             }
     }

 });