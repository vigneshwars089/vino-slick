var app= angular.module('App',['ui.router','ngMaterial','angularLoad','ui.bootstrap','angularSpinners','ngFileUpload'])
app.config(function($stateProvider, $urlRouterProvider,  $locationProvider){
  $urlRouterProvider.otherwise('errorPage');
  $stateProvider
  .state('solution',{
    url:'/solution',
    templateUrl:'views/main.html'
  })
  .state('solution.home',{
    url:'/',
    templateUrl:'views/carouselPage.html'

  })
  .state('solution.search',{
    url:'/',
    templateUrl:'views/search.html'

  })
  .state('solution.accountsList',{
    url:'/',
    templateUrl:'views/accountsList.html'

  })
  .state('solution.conceptMap',{
    url:'/conceptMap/:toolName',
    templateUrl:'views/conceptMap.html'
  })
  .state('login',{
    url:'/login',
    templateUrl:'views/login.html',
    controller:"LoginCtrl"
  })
  .state('initial',{
    url:'',
    templateUrl:'views/login.html',
    controller:"LoginCtrl"
  })
  .state('welcomePage',{
        url:'/',
        templateUrl:'views/welcomePage.html'
  })
  .state('errorPage',{
        url:'/',
        templateUrl:'views/errorPage.html'
  })
  .state('process',{
        url:'/process',
        templateUrl:'views/process.html'
  })
  .state('process.processAccountsPage',{
        url:'/accounts',
        templateUrl:'views/processAccountsPage.html'
  })
  .state('process.processSearch',{
        url:'/search',
        templateUrl:'views/processSearch.html'
  })
  .state('process.processCarouselPage',{
        url:'/home',
        templateUrl:'views/processCarouselPage.html'
  })
  .state('solution.fileUpload',{
    url:'/upload',
    templateUrl:'views/uploadPage.html'
  })
    .state('bot', {
        url: '/bot',
        templateUrl: 'views/botHome.html'
    })
  .state('botResume', {
      url: '/botResume',
      templateUrl: 'views/try.html'
  });
});
