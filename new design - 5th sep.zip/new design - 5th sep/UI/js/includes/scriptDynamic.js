! function() {
    "use strict";
    angular.module("angularLoad", []).service("angularLoad", ["$document", "$q", "$timeout", function(a, b, c) {
        function d(a) {
            return function(d) {
                if ("undefined" == typeof f[d] || "undefined" != typeof f[d]) {
                    var e = b.defer(),
                        g = a(d);
                    g.onload = g.onreadystatechange = function(a) {
                        g.readyState && "complete" !== g.readyState && "loaded" !== g.readyState || c(function() {
                            e.resolve(a)
                        })
                    }, g.onerror = function(a) {
                        c(function() {
                            e.reject(a)
                        })
                    }, f[d] = e.promise
                }
                return f[d]
            }
        }
        var e = a[0],
            f = {};
        this.loadScript = d(function(a) {
            var b = e.createElement("script");
            return b.src = a, e.body.appendChild(b), b
        }), this.loadCSS = d(function(a) {
            var b = e.createElement("link");
            return b.rel = "stylesheet", b.type = "text/css", b.href = a, e.head.appendChild(b), b
        }), this.unloadCSS = function(a) {
            delete f[a];
            var b = e.head;
            if (b) {
                var c = b.querySelector('[href="' + a + '"]');
                if (c) return c.remove(), !0
            }
            return !1
        }
    }])
}();
//# sourceMappingURL=angular-load.min.js.map
