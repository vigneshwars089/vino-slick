angular.module('App')
.factory('GetNameService', function($http, $q) {
  return {
        getName: function(str) {
            var url = "https://digitalopssolutionscatalogservice.cognizant.com/Solution/auto_nodes/" + str;
            return $http.get(url,{headers:  {
                    'AuthorizationToken': token
                  }})
                .then(function(response) {
                    if (typeof response.data === 'object')
                        return response.data;
                    else
                        return $q.reject(response.data);
                }, function(response) {
                    return $q.reject(response.data);
                });
        }
    };
});
angular.module('App').factory('GetNameServiceProcess', function($http, $q) {
  return {
        getName: function(str) {
            return  $http({
                    method: "GET",
                    url: "https://digitalopssolutionscatalogservice.cognizant.com/Process/api/ProcessCatalog/autocompleteData",
                    params: {
                        input : str,
                    }
                }).then(function(result){
                    var r = JSON.parse(result.data)
                    return r;
                 });
        }
    };
});
angular.module('App').factory('sharedURL', function () {
        var url = 'https://digitalopssolutionscatalogservice.cognizant.com/Solution';
        var urlProcess = 'https://digitalopssolutionscatalogservice.cognizant.com/Process/api/ProcessCatalog';
        return {
            getURL: function () {
                return url;
            },
            getURLProcess: function () {
                return urlProcess;
            }
        };
    });
angular.module('App').service('userDetails', function() {
  var userDetails={};
        this.inputDeatils = function (data) {
            userDetails=data;
          
        }
        this.requiredDeails=function(field){
          return userDetails[field];
        }
    });
